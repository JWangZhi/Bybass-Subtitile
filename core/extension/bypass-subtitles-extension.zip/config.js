/**
 * Bypass Subtitles Extension Configuration
 * 
 * This file is GIT-IGNORED. Do not commit sensitive keys.
 * Created automatically for local development.
 */

const config = {
    // Current Local Backend
    backendUrl: 'http://localhost:8765',

    // API Secret from .env (e3b0...)
    apiSecret: 'e3b0c44298fc1c149afbf4c893zfb92427ae41e4649b934ca493991b7852b855'
};

export default config;
